# k3d-practice
This is my repo to practice k8s and Argocd
